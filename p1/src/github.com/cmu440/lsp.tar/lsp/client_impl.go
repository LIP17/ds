// Contains the implementation of a LSP client.
// Name : Li Pei
// Andrew ID : lip
package lsp

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/cmu440/lspnet"
)

type client struct {
	// TODO: implement this!

	// connection ID
	connID int
	conn   *lspnet.UDPConn
	addr   *lspnet.UDPAddr

	// write function group

	nextWriteIndex int

	writeToServerChan     chan []byte
	clientWriteMethodChan chan []byte

	// read function group

	haveBeenReadIndex int

	recvFromServerChan chan Message

	clientCloseMethodChanResponse chan bool
	clientGoingToClose            bool
	clientCloseMethodChan         chan struct{}

	successConnect             chan bool
	alreadyShutDown            bool
	clientReadMethodBufferChan chan Message
}

// NewClient creates, initiates, and returns a new client. This function
// should return after a connection with the server has been established
// (i.e., the client has received an Ack message from the server in response
// to its connection request), and should return a non-nil error if a
// connection could not be made (i.e., if after K epochs, the client still
// hasn't received an Ack message from the server in response to its K
// connection requests).
//
// hostport is a colon-separated string identifying the server's host address
// and port number (i.e., "localhost:9999").
func NewClient(hostport string, params *Params) (Client, error) {

	udpaddr, err := lspnet.ResolveUDPAddr("udp", hostport)
	if err != nil {
		return nil, err
	}

	udpconn, err := lspnet.DialUDP("udp", nil, udpaddr)
	if err != nil {
		return nil, err
	}

	c := new(client)

	// connection ID
	// c.connID : waiting for Server to offer
	c.conn = udpconn
	c.addr = udpaddr

	// write function group

	c.nextWriteIndex = 1

	c.writeToServerChan = make(chan []byte)
	c.clientWriteMethodChan = make(chan []byte)

	// read function group

	c.haveBeenReadIndex = 0

	c.recvFromServerChan = make(chan Message)

	c.clientCloseMethodChanResponse = make(chan bool)
	c.clientGoingToClose = false
	c.clientCloseMethodChan = make(chan struct{})

	c.successConnect = make(chan bool)
	c.alreadyShutDown = false
	c.clientReadMethodBufferChan = make(chan Message, 10000)

	go c.eventHandler()
	go c.writeToServer()
	go c.readFromServer()

	return c.launch()

	// return nil, errors.New("not yet implemented")
}

func (c *client) launch() (Client, error) {
	mes := NewConnect()

	buf, _ := json.Marshal(mes)

	c.writeToServerChan <- buf
	for {
		select {
		case <-c.successConnect:
			fmt.Printf("Build Conn ID : %d\n", c.connID)

			return c, nil
		}
	}

	// return c, nil
}

func (c *client) writeToServer() {
	for {
		select {
		case buf := <-c.writeToServerChan:
			c.conn.Write(buf)
		}
	}
}

func (c *client) readFromServer() error {
	var buf [1500]byte
	var mes Message
	for {
		if c.alreadyShutDown {
			return nil
		}

		n, err := c.conn.Read(buf[0:])

		// fmt.Println("read WriteBack")

		if err != nil {
			c.clientCloseMethodChan <- struct{}{}
			return nil
		}

		json.Unmarshal(buf[0:n], &mes)

		fmt.Printf("Read From Server %d, %s\n", mes.Type, string(mes.Payload))
		c.recvFromServerChan <- mes
	}
}

func (c *client) eventHandler() {
	for {
		select {
		case buf := <-c.clientWriteMethodChan:
			mes := NewData(c.connID, c.nextWriteIndex, buf, nil)
			c.nextWriteIndex++
			sendBuf, _ := json.Marshal(mes)
			c.writeToServerChan <- sendBuf
			// fmt.Println("finished write")

		case mes := <-c.recvFromServerChan:
			fmt.Printf("recvFromServerChan : type %d, %s\n", mes.Type, string(mes.Payload))

			if mes.Type == MsgAck {
				c.connID = mes.ConnID
				c.successConnect <- true
				// fmt.Println("MsgAck")
				// fmt.Println(mes.ConnID)
			}

			if mes.Type == MsgData {

				fmt.Printf("What I really read in ? : %s\n", mes.Payload)
				// fmt.Println("Write back to buffer chan?")

				mes := NewData(c.connID, c.nextWriteIndex, mes.Payload, nil)
				c.nextWriteIndex++
				// fmt.Println("MsgData")
				// fmt.Println(mes.Type)
				c.clientReadMethodBufferChan <- *mes
			}

		case <-c.clientCloseMethodChan:
			c.clientCloseMethodChanResponse <- true
		}

	}
}

func (c *client) ConnID() int {
	return c.connID
}

func (c *client) Read() ([]byte, error) {
	// TODO: remove this line when you are ready to begin implementing this method.
	if c.alreadyShutDown {
		return nil, errors.New("Read From Terminated Connection")
	}

	msg, ok := <-c.clientReadMethodBufferChan
	if ok {
		fmt.Printf("return payload : %s\n", msg.Payload)
		return msg.Payload, nil
	} else {
		return nil, errors.New("connection closed")
	}

	return nil, errors.New("not yet implemented")
}

func (c *client) Write(payload []byte) error {

	c.clientWriteMethodChan <- payload

	return nil
	// return errors.New("not yet implemented")
}

func (c *client) Close() error {

	c.clientCloseMethodChan <- struct{}{}
	select {
	case boo := <-c.clientCloseMethodChanResponse:
		if boo {
			c.closeAllThing()
			return nil
		} else {
			return errors.New("Connectin is closed but message not all sent")
		}
	}

	return nil
}

func (c *client) closeAllThing() {
	c.alreadyShutDown = true
	close(c.clientWriteMethodChan)
	c.conn.Close()
	close(c.clientReadMethodBufferChan)
}
