// Contains the implementation of a LSP server.
// Name : Li Pei
// Andrew ID : lip
package lsp

import (
	"container/list"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/cmu440/lspnet"
	"strconv"
)

type clientProxy struct {
	clientAddr *lspnet.UDPAddr
	connID     int

	nextWriteSeqIndex int
	successWriteIndex int
	sendWindow        map[int]bool
	sendMessageChan   chan Message
	sendMessageQueue  *list.List

	successReadIndex  int
	haveBeenReadIndex int

	recvMessageChan  chan Message
	recvMessageQueue *list.List

	recvWindow         map[int]bool
	clientGoingToClose bool
	clientCloseChan    chan struct{}
	clientShutDownChan chan struct{}
}

type server struct {
	// TODO: implement this!
	conn         *lspnet.UDPConn
	nextClientID int
	clientQueue  map[int]*clientProxy
	windowSize   int

	// server write
	serverWriteMethodChan         chan Message
	serverWriteMethodChanResponse chan bool

	// server read
	clientConnChan             chan *lspnet.UDPAddr
	serverReadMethodBufferChan chan Message

	// close issue
	clientEOF chan int

	serverGoingToClose bool

	serverCloseConnMethodChan         chan int
	serverCloseConnMethodChanResponse chan bool
	serverCloseMethodCollect          chan struct{}
	serverCloseMethodChan             chan struct{}
	serverCloseMethodChanResponse     chan bool
}

// NewServer creates, initiates, and returns a new server. This function should
// NOT block. Instead, it should spawn one or more goroutines (to handle things
// like accepting incoming client connections, triggering epoch events at
// fixed intervals, synchronizing events using a for-select loop like you saw in
// project 0, etc.) and immediately return. It should return a non-nil error if
// there was an error resolving or listening on the specified port number.
func NewServer(port int, params *Params) (Server, error) {

	addr, err := lspnet.ResolveUDPAddr("udp", lspnet.JoinHostPort("localhost", strconv.Itoa(port)))
	if err != nil {
		return nil, err
	}

	conn, err := lspnet.ListenUDP("udp", addr)
	if err != nil {
		return nil, err
	}

	s := new(server)

	s.conn = conn
	s.nextClientID = 1
	s.clientQueue = make(map[int]*clientProxy)
	s.windowSize = params.WindowSize

	// server write
	s.serverWriteMethodChan = make(chan Message)
	s.serverWriteMethodChanResponse = make(chan bool)

	// server read
	s.clientConnChan = make(chan *lspnet.UDPAddr)
	s.serverReadMethodBufferChan = make(chan Message)

	// close issue
	s.clientEOF = make(chan int)

	s.serverGoingToClose = false

	s.serverCloseConnMethodChan = make(chan int)
	s.serverCloseConnMethodChanResponse = make(chan bool)
	s.serverCloseMethodCollect = make(chan struct{})
	s.serverCloseMethodChan = make(chan struct{})
	s.serverCloseMethodChanResponse = make(chan bool)

	go s.EventHandler()
	go s.readFromAllClients()

	return s, nil
	// return nil, errors.New("not yet implemented")
}

func (s *server) EventHandler() {
	for {
		select {
		case addr := <-s.clientConnChan:
			c := new(clientProxy)
			c.clientAddr = addr

			c.connID = s.nextClientID
			s.nextClientID++

			c.nextWriteSeqIndex = 1
			c.successWriteIndex = 0
			c.sendWindow = make(map[int]bool)
			c.sendMessageChan = make(chan Message)
			c.sendMessageQueue = list.New()

			c.successReadIndex = 0
			c.haveBeenReadIndex = 0

			c.recvMessageChan = make(chan Message)
			c.recvMessageQueue = list.New()

			c.recvWindow = make(map[int]bool)
			c.clientGoingToClose = false
			c.clientCloseChan = make(chan struct{})
			c.clientShutDownChan = make(chan struct{})

			s.clientQueue[c.connID] = c

			go c.clientEventHandler(s)

			ack := NewAck(c.connID, 0)
			buf, _ := json.Marshal(*ack)
			s.conn.WriteToUDP(buf, c.clientAddr)
		case mes := <-s.serverWriteMethodChan:
			s.serverWriteMethodChanResponse <- true
			s.clientQueue[mes.ConnID].sendMessageChan <- mes

		case <-s.serverCloseMethodChan:
			s.serverGoingToClose = true

			clientInfoLen := len(s.clientQueue)

			for i := 0; i < clientInfoLen; i++ {
				<-s.serverCloseMethodCollect
			}

			s.serverCloseMethodChanResponse <- true
		case connID := <-s.serverCloseConnMethodChan:
			if c, ok := s.clientQueue[connID]; ok {
				s.serverCloseMethodChanResponse <- true
				c.clientCloseChan <- struct{}{}
				delete(s.clientQueue, connID)
			} else {
				s.serverCloseConnMethodChanResponse <- false
			}

		}
	}
}

func (c *clientProxy) clientEventHandler(s *server) {
	for {
		select {
		case mes := <-c.sendMessageChan:

			buf, _ := json.Marshal(mes)
			s.conn.WriteToUDP(buf, c.clientAddr)

		case mes := <-c.recvMessageChan:

			if mes.Type == MsgAck {

			} else {
				s.serverReadMethodBufferChan <- mes

				fmt.Print("receive")
				fmt.Println(string(mes.Payload))
				// mes := NewAck(c.connID, c.nextWriteSeqIndex)
				// c.successReadIndex++

				// buf, _ := json.Marshal(mes)

				// s.conn.WriteToUDP(buf, c.clientAddr)
			}

		case <-c.clientCloseChan:
			c.clientGoingToClose = true
		}
	}
}

func (s *server) readFromAllClients() {
	var buf [1500]byte
	var mes Message

	for {
		n, addr, err := s.conn.ReadFromUDP(buf[0:])
		if err != nil {
			fmt.Println("Error of read from UDP")
			return
		}

		json.Unmarshal(buf[0:n], &mes)

		if mes.Type == MsgConnect {
			if !s.serverGoingToClose {
				s.clientConnChan <- addr
				// fmt.Println("send ID back")
			}
		} else {
			for _, c := range s.clientQueue {
				if c.connID == mes.ConnID {
					c.recvMessageChan <- mes
					break
				}
			}
		}
	}

}

func (s *server) Read() (int, []byte, error) {
	// TODO: remove this line when you are ready to begin implementing this method.
	select {
	case mes := <-s.serverReadMethodBufferChan:
		return mes.ConnID, mes.Payload, nil
	case connID := <-s.clientEOF:
		return connID, nil, errors.New("client has been closed")

	} // Blocks indefinitely.
	// return -1, nil, errors.New("not yet implemented")
}

func (s *server) Write(connID int, payload []byte) error {
	mes := NewData(connID, -1, payload, nil)
	s.serverWriteMethodChan <- *mes
	fmt.Printf("srunner call Write ID :%d : %s\n", mes.ConnID, mes.Payload)
	select {
	case ok := <-s.serverWriteMethodChanResponse:
		if ok {
			return nil
		} else {
			return errors.New("This ConnID did not exist")
		}
	}
	// return errors.New("not yet implemented")
}

func (s *server) CloseConn(connID int) error {
	s.serverCloseConnMethodChan <- connID

	select {
	case ok := <-s.serverCloseConnMethodChanResponse:
		if ok {
			return nil
		} else {
			return errors.New("This ConnID did not exist")
		}

	}
	// return errors.New("not yet implemented")
}

func (s *server) Close() error {

	s.serverGoingToClose = true

	s.serverCloseMethodChan <- struct{}{}

	for _, c := range s.clientQueue {
		c.clientCloseChan <- struct{}{}
	}

	flag, _ := <-s.serverCloseMethodChanResponse
	if flag {
		return nil
	} else {
		return errors.New("Remaining Clients!")
	}

	// return errors.New("not yet implemented")
}
